# python module 4 code

from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self,username,password):
        # innit to connect to mongodb without authentication
        self.client = MongoClient('mongodb://localhost:38658')
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        #self.client = MongoClient('mongodb://%s:%s@localhost:38658/?authMechanism=DEFAULT&authSource=AAC'%(username, password))
        self.database = self.client['AAC']

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            self.database.animals.insert(data)  # data should be dictionary            
        else:
            raise Exception("Nothing to save, because data parameter is empty")

# Create method to implement the R in CRUD.
    def read_all(self,data):
        cursor = self.database.animals.find(data, {'_id':False} )
        return cursor
    
    def read(self,search):
        if search is not None:
            searchResult = self.database.animals.find_one(search)
            return searchResult
        else:
            raise Exception("Nothing to search, because search parameter is empty")
    
# Create method to implement U in CRUD.
    def update(self,save):
        if save is not None:
                saveResult = self.database.animals.insert_one(save)
                return saveResult
        else:
                raise Exception("Nothing to update, because save parameter is empty")
        
# Create method to implement D in CRUD.
    def delete(self,remove):
        if remove is not None:
                removeResult = self.database.animals.delete_one(remove)
                return removeResult
        else:
                raise Exception("Nothing to delete, because remove parameter is empty")